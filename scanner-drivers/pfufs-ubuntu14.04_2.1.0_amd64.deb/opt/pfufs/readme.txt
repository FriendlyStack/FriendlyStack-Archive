------------------------------------------------------------------------
fi Series
Image scanner driver for Linux 2.1.0
README file
------------------------------------------------------------------------
Copyright PFU Limited 2017


This file includes important notes on this product and also the additional information.

------------------------------------------------------------------------
Table of Contents
------------------------------------------------------------------------
1. Use in High-Safety Applications
2. Copies
3. System Requirements
4. Installation/Uninstallation
5. Monitoring Tool for the [Scan] button
6. Notes on Scanning
7. Notes on Scan Settings


---------------------------------------------------
1. Use in High-Safety Applications
---------------------------------------------------

This product has been designed and manufactured on the assumption that it will be used in office, personal, domestic, regular industrial, and general-purpose applications.
It has not been designed and manufactured for use in applications (simply called "high-safety applications" from here on) that directly involve danger to life and health when a high degree of safety is required, for example, in the control of nuclear reactions at nuclear power facilities, automatic flight control of aircraft, air traffic control, operation control in mass-transport systems, medical equipment for sustaining life, and missile firing control in weapons systems, and when provisionally the safety in question is not ensured.
The user should use this product with adopting measures for ensuring safety in such high-safety applications. PFU LIMITED assumes no liability whatsoever for damages arising from use of this product by the user in high-safety applications, and for any claims or compensation for damages by the user or a third party.


---------------------------------------------------
2. Copies
---------------------------------------------------

- Scanning paper currencies, negotiable instruments or official documents with a scanner, printing them out with a printer and using their unauthorized copy is a violation of the law regardless of their printed matter, and you will be subject to punishment.

- Making a copy of creative works such as newspapers, magazines, books which are subject to copyright protection, without permission of the right holder, except the reproduction for personal use, for private use at home or equivalent purpose within the limited range, is prohibited by law. Use the data scanned with a scanner within the range of private use.


---------------------------------------------------
3. System Requirements
---------------------------------------------------

- Operating system
  Ubuntu 14.04/16.04 LTS (Desktop, 32bit/64bit)

- CPU
  Intel(R) Core(TM) i5 desktop processor 2.5 GHz or higher recommended

- Memory
  4 GB or more recommended

- Target devices
    fi Series scanner (fi-7030/fi-7140/fi-7240/fi-7160/fi-7260/fi-7180/fi-7280/fi-7460/fi-7480)

---------------------------------------------------
4. Installation/Uninstallation
---------------------------------------------------
Notes: The following installation/uninstallation procedure is explained with an example taken from the fi Series driver (for Ubuntu 64bit). When reading this procedure, replace the package name (pfufs) and the package file name (pfufs-ubuntu14.04_2.1.0_amd64.deb) with the relevant ones in accordance with the scanner and OS that you are using.

- Preparation in advance
    - Copy this product package to the computer that you intend to install it on.
    - Turn off the scanner and disconnect the USB cable that is connected to the computer.
- How to install
    The installation procedure is as follows:
(1) Start up and log into Ubuntu, and then open terminal software.
(2) Execute the "sudo" command and enter the super user (root user) password to become a root user.
(3) Execute the "uname -m" command to check that the OS type of Ubuntu matches the one that you desire.
(4) By using  the "cd" command, open the folder that the package of pfufs-ubuntu14.04_2.1.0_amd64.deb is saved in.
(5) Execute "dpkg -i pfufs-ubuntu14.04_2.1.0_amd64.deb" to install the package.
(6) Execute "dpkg -l pfufs" to check that the package has been installed successfully. When the package name "pfufs" is displayed, the installation is successfully complete.
(7) Connect the scanner to the computer and turn on the scanner.
(8) Start up a tool to check operations such as "scanimage" and check the scanning operations.

- How to uninstall
    The uninstallation procedure is as follows:
(1) Turn off the scanner.
(2) Open terminal software.
(3) Execute the "sudo" command and enter the super user (root user) password to become a root user.
(4) Execute "dpkg -r pfufs" to uninstall the package.
(5) Execute "dpkg --purge pfufs" to delete the information of the package.
(6) Execute "dpkg -l pfufs" to check that the package has been uninstalled successfully. When the package information of "pfufs" is not shown, the uninstallation is  complete successfully.

- Complementary information
  - Uninstalling this product does not delete the scanned images.
  - To know the OS type, check the execution result of "uname -m".
    - When "i386" or "i686" is shown, the type is a 32bit operating system.
    - When "x86_64" is shown, the type is a 64bit operating system.

---------------------------------------------------
5. Monitoring Tool for the [Scan] button
---------------------------------------------------
  This tool monitors the [Scan] button and executes the "scanimage" command to scan a document when it detects that the [Scan] button has been pressed.
The following describes how to use this tool:

(1) How to start up and stop the monitoring tool
      The monitoring tool does not start up immediately after it is installed.
      To start up or stop this tool, perform the following operation as a super user (root).

    Starting up the monitoring tool	/etc/init.d/pfufsscanbutton start
    Stopping the monitoring tool	/etc/init.d/pfufsscanbutton stop

   To run the monitoring tool as a resident tool automatically after the system is started-up, this tool must be registered.
   Use the "update-rc.d"  command to register this tool in the system or to unregister this tool from the system.
   Example:
      Registering:
           update-rc.d  -f  pfufsscanbutton defaults
      Unregistering:
           update-rc.d  -f  pfufsscanbutton remove
   
(2) The destination that the scanned images are saved in
  When the [Scan] button is pressed to scan a document, the scanned image is saved in the current time folder that is created in the following folder.
      /opt/pfufs/image
  The created image file has the attributes below. In addition, the image is output in the PNM image format by default.
      Owner: root
      Permission: 644

(3) How to change the scan parameters
  When the [Scan] button is pressed, the scan is performed in accordance with the configuration file below.
  To change the scan parameters, edit the configuration file below. Note that the default image format is tiff or PNM due to the specifications of "scanimage". To change the image format to a different format, use an image conversion application or another tool.
      /opt/pfufs/etc/pfufsscanbutton.conf

  Example of the configuration file: When this tool is installed, the configuration file with the following parameters is also installed:
     scanimage --batch --format=pnm --source "Adf-front" --mode lineart --resolution 300 --autofeed=yes
  *Notes: The contents of this configuration file cannot be written as a shell script. This file can be used only as an option for the "scanimage" command.

(4) Points of attention
- When a the scanner is in use (for example, when a scanning application is using the scanner), the monitoring tool cannot start scanning even if the [Scan] button is pressed.
  On the other hand, when a scan is being performed by the monitoring tool due to the [Scan] button being pressed, other applications cannot start scanning.
- The monitoring tool can monitor only one scanner. When multiple scanners are connected to the computer, the monitoring tool does not run correctly.

---------------------------------------------------
6. Notes on Scanning
---------------------------------------------------

- Do not let your computer enter standby mode during scanning. Otherwise, scanning may fail due to the "Error during device I/O" error and so on.

- Do not unplug the power cable or interface cable during scanning. Otherwise, scanning may fail due to the "Error during device I/O" error and so on. In that case, connect the USB cable again and power on the scanner to make the computer recognize the scanner.

- Do not log off your computer during scanning. Otherwise, scanning may fail due to the "Error during device I/O" error and so on.

- The Ubuntu system already has the sane-fujitsu (SANE backend) driver for fi Series installed on it. If you install this driver, the sane-fujitsu driver becomes unusable in order to avoid a conflict with this driver. Uninstall this driver when you need to use the sane-fujitsu driver again. To view the details about the sane-fujitsu driver, execute "man sane-fujitsu".
 Note that, when using xsane, you need to delete the old configuration file that is created by xsane every time you switch drivers. Perform the following operation.
         rm -f ~/.sane/xsane/FUJITSU*

---------------------------------------------------
7. Notes on Scan Settings
---------------------------------------------------

Notes on the following scanning options are described.

(1) autofeed
  A preceding scan is performed by using the cache memory in the scanner. Because all sheets that are loaded in the feeder are fed, if an application stops the scanning process along the way, the scanned images that remain in the cache memory are discarded. By default, this option is set to "yes". To scan one sheet per scan, set this option to "no".

(2) page-auto
  - When the crop function is used, the function to specify the scanning area cannot be used.
    Options -l, -t, -x, -y are ignored.
  - When the crop function is not used, up to 3200 mm can be specified for the -t (Top-left y) option for the following models:
    fi-7140/fi-7240/fi-7160/fi-7260/fi-7180/fi-7280
  - When paper larger than the specified paper size is scanned, the crop function is not available.


------------------------------------------------------------------------
The following component is used in this product:

  This software is based in part on the work of Independent JPEG Group.
  The Graphics Interchange Format(c) is the Copyright property of CompuServe Incorporated.
  GIF(sm) is a Service Mark property of CompuServe Incorporated.
------------------------------------------------------------------------
- Linux is the registered trademark or trademark of Linus Torvalds in the U.S. and other countries.
- Ubuntu is registered trademarks of Canonical Ltd.
- Intel and Intel Core are registered trademarks or trademarks of Intel Corporation in the United States and other countries.
- Other company name and product name are trademarks or registered trademarks of individual companies
